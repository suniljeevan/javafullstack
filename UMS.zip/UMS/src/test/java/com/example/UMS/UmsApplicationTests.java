package com.example.UMS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
